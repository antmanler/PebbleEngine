
#include <fstream>
#include <limits>
#include <cmath>

#include <QMessageBox>
#include <QApplication>
#include <QTime>
#include <QKeyEvent>
#include <QFile>

#include <Core.h>
#include <Mouse.h>
#include <Horde3D/Horde3DUtils.h>
#include <Horde3D/Horde3DSph.h>
#include <Engine/Horde3DPhysics.h>

#include "GLPlayerWidget.h"


QSimpleInputContext QSimpleInputContext::instance_ ;

QSimpleInputContext::QSimpleInputContext()
    :key_(0), clicked_key_(0), button_(0), clicked_button_(0), x_(0), y_(0),
      key_clicked_(false), key_pressed_(false),
      button_clicked_(false), button_pressed_(false)
{
}

QSimpleInputContext* QSimpleInputContext::instance()
{
    return &instance_;
}

void QSimpleInputContext::SetMouseState(Qt::MouseButton button, bool pressed, int x, int y)
{
    if (pressed) {
        button_clicked_ = false ;
    } else if (button_pressed_) {
        button_clicked_ = true ;
        clicked_button_ = button_;
    }
    
    button_ = button ;
    button_pressed_ = pressed ;
    x_ = x; y_ = y;
}

void QSimpleInputContext::SetKeyState(Qt::Key key, bool pressed)
{
    if (pressed) {
        key_clicked_ = false ;
    } else if (key_pressed_) {
        key_clicked_ = true ;
        clicked_key_ = key_;
    }
    
    key_ = key;
    key_pressed_ = pressed ;
}

Qt::KeyboardModifiers QSimpleInputContext::modifier() const
{
    return QApplication::keyboardModifiers();
}

int SPHExp::LoadVolumeData(const char *filename, int smooth_level)
{
    using namespace std ;
    ifstream input(filename, ios::in|ios::binary);
    if(input == NULL) return false;
    
    int nbparticles = 0 ;
    input.read((char*)&nbparticles, sizeof(int));
    
    if(!nbparticles) return false;
    
    vec3 *p = new vec3[nbparticles];
#undef max
#undef min
    static const float max_float = std::numeric_limits<float>::max();
    static const float min_float = std::numeric_limits<float>::min();
    vec3 min_pos(max_float), max_pos(min_float);
    
    for (int i=0; i<nbparticles; ++i) {
        input.read((char*)&(p[i].x), sizeof(float));
        input.read((char*)&(p[i].y), sizeof(float));
        input.read((char*)&(p[i].z), sizeof(float));
        
        // update bounding box
        min_pos.x = min_pos.x > p[i].x ? p[i].x : min_pos.x;
        min_pos.y = min_pos.y > p[i].y ? p[i].y : min_pos.y;
        min_pos.z = min_pos.z > p[i].z ? p[i].z : min_pos.z;
        
        max_pos.x = max_pos.x < p[i].x ? p[i].x : max_pos.x;
        max_pos.y = max_pos.y < p[i].y ? p[i].y : max_pos.y;
        max_pos.z = max_pos.z < p[i].z ? p[i].z : max_pos.z;
        //        if(1 == changez)  p[i].z = 1 - p[i].z;
    }
    input.close();
    
    // limits to this, since 256x256x256 great than ten million
    static const unsigned int MAX_EXTEND = 256;
    vec3 extend = max_pos - min_pos;

    // calculate volume per particle
    float vp = extend.x*extend.y*extend.z / nbparticles;
    
    smooth_level = smooth_level >= 100 ? 99 : smooth_level;
    smooth_level = smooth_level <  0   ? 0  : smooth_level;
    
    float stride = powf(vp, 0.3)*(static_cast<float>(100 - smooth_level)/100.0);
    float stride_inv = 1.0/stride;
    float sv = 0.125*stride*stride*stride ;
    
    int width = extend.x * stride_inv;
    int height = extend.y * stride_inv;
    int depth = extend.z * stride_inv;
    
    vec3 scale(1.0f);
    if (width > MAX_EXTEND) {
        scale.x = MAX_EXTEND / width;
        width = MAX_EXTEND;
    }
    if (height > MAX_EXTEND) {
        scale.y = MAX_EXTEND / height;
        height = MAX_EXTEND;
    }
    if (depth > MAX_EXTEND) {
        scale.z = MAX_EXTEND / depth;
        depth = MAX_EXTEND;
    }
    
    int res = h3dextCreate3DTexture("volume_sampler", width, height, depth, H3DFormats::TEX_RGBA32F, H3DResFlags::NoTexMipmaps);
    
    if ( 0 == res ) {
        delete []p;
        return 0;
    }
    
    float* data = static_cast<float*>(h3dMapResStream(res, H3DTexRes::ImageElem, 0, H3DTexRes::ImgPixelStream, false, true ));
    
    memset(data, 0, sizeof(float)*width*height*depth*4);
    
    for (int i=0; i<nbparticles; ++i) {
        vec3 &pos = p[i];
        float x_f=pos.x * stride_inv * scale.x;
        float y_f=pos.y * stride_inv * scale.y;
        float z_f=pos.z * stride_inv * scale.z;
        int x = static_cast<int>(x_f);
        int y = static_cast<int>(y_f);
        int z = static_cast<int>(z_f);
        float dx = x_f-x, dy = y_f-y, dz = z_f-z;
        if (dx*dy*dz < sv) continue ;
        
        data[(x + y*width + z*width*height)*4 + 0] = x_f;
        data[(x + y*width + z*width*height)*4 + 1] = x_f;
        data[(x + y*width + z*width*height)*4 + 2] = x_f;
        data[(x + y*width + z*width*height)*4 + 3] = stride;
    }
    
    h3dUnmapResStream(res);
    
    delete[] p;
    return res;
}

bool SPHExp::UpdateSphData(int sphres, const char* filename)
{
    using namespace std ;
    ifstream input(filename, ios::in|ios::binary);
    if(input == NULL) return false;
    size_t length = 0;
    input.seekg (0, ios::end);
    length = input.tellg();
    input.seekg (0, ios::beg);
    
    if (length > len_) {
        if (buf_) delete []buf_ ;
        len_ = static_cast<int>(length * 2.0);
        buf_ = new char[len_];
    }
    bool ret = (input.read(buf_, length).rdstate() & ifstream::failbit) == 0 ;
    input.close() ;
    ret = ret && h3dextUpdateSphData(sphres, buf_, length) ;
    
    return ret;
}

void SPHExp::AdvanceSph(int sphnode)
{
    h3dextUpdateSphNode(sphnode);
}

GLPlayerWidget::GLPlayerWidget(QWidget *parent)	
    : QGLWidget(parent),
      initialized_( false ),
      frame_id_(0),
      frame_skip_(true),
      timer_id_(0)
{	
    m_fullScreen = false;
    camera_ctrl_ = new TrackballManipulator();
    setFocusPolicy(Qt::StrongFocus);
}

GLPlayerWidget::~GLPlayerWidget()
{
    if (camera_ctrl_) {
        delete camera_ctrl_;
    }
    if (initialized_) {
        h3dRelease() ;
        h3dextReleasePhysics() ;
    }
}

void GLPlayerWidget::SetCurrentCamera(int camera)
{
    if (0 == camera) {
        int cnt = h3dFindNodes(H3DRootNode, "__default_camera__", H3DNodeTypes::Camera) ;
        if (cnt == 0) return ;
        cur_camera_ = h3dGetNodeFindResult(0);
    } else {
        cur_camera_ = camera ;
    }
    
    QSize sz = size() ;
    if (sz.width() > 0 && sz.height() > 0 && initialized_) {
        int width = sz.width(), height = sz.height();
        // Resize viewport
        h3dSetNodeParamI( cur_camera_, H3DCamera::ViewportXI, 0 );
        h3dSetNodeParamI( cur_camera_, H3DCamera::ViewportYI, 0 );
        h3dSetNodeParamI( cur_camera_, H3DCamera::ViewportWidthI, width );
        h3dSetNodeParamI( cur_camera_, H3DCamera::ViewportHeightI, height );
        
        // Set virtual camera parameters
        h3dSetupCameraView( cur_camera_, 45.0f, (float)width / height, 0.1f, 1000.0f );
        H3DRes pipeline = h3dGetNodeParamI( cur_camera_, H3DCamera::PipeResI ) ;
        h3dResizePipelineBuffers( pipeline, width, height );
    }
    
    if (h3dGetNodeParent(cur_camera_) != camera_anchor_) {
        h3dSetNodeParent(cur_camera_, camera_anchor_) ;
    }
    
    camera_ctrl_->setCamera(camera);
    
}

void GLPlayerWidget::initializeGL()
{
    Reset() ;
}

void GLPlayerWidget::Reset()
{

    blockSignals(true) ;
    if (timer_id_) {
        killTimer(timer_id_);
    }
    
    if (initialized_) {
        h3dRelease() ;
        h3dextReleasePhysics() ;
        initialized_ = false ;
    }
    
    makeCurrent() ;
    
    if ( ( initialized_ = h3dInit() ) == false) {
        h3dutDumpMessages();
        QMessageBox::warning(this, tr("Error"), tr("Error initializing Horde3D!"));
    }
    h3dextInitPhysics() ;
    
    blockSignals(false) ;
    
    emit set_engine_options() ;
    
    m_curFPS = 30;
    
    m_statMode = 0;
    m_freeze = false; m_debugViewMode = false; m_wireframeMode = false;
    m_animTime = 0;
    m_weight = 1;
    cur_camera_ = 0;
    camera_anchor_ = 0;
    
    // clear eveything
    h3dextClearPhysics();
    h3dClear();
    
    m_fontMatRes = h3dAddResource( H3DResTypes::Material, "overlays/font.material.xml", 0 );
    m_panelMatRes = h3dAddResource( H3DResTypes::Material, "overlays/panel.material.xml", 0 );
    m_logoMatRes = h3dAddResource( H3DResTypes::Material, "overlays/logo.material.xml", 0 );
    H3DRes simple_pipeline = h3dAddResource( H3DResTypes::Pipeline, "pipelines/simple.pipeline.xml", 0 );
    h3dAddCameraNode( H3DRootNode, "__default_camera__", simple_pipeline );

    load_res_frome_qrc() ;
    
    // load resource
    emit load_resource() ;
    emit setup_scene() ;
    
    // add phyiscs nodes
    int nodes = h3dFindNodes( H3DRootNode, "", H3DNodeTypes::Undefined );
    for (int i = 0; i < nodes; ++i) {
        H3DNode node = h3dGetNodeFindResult(i);
        std::string attchstr = h3dGetNodeParamStr(node, H3DNodeParams::AttachmentStr) ;
        h3dextCreatePhysicsNode( attchstr.c_str(), node );
    }
    h3dextResetPhysics();
    
    // create an anchor node, so that the camera can always rotate around a relative (0, 0, 0) point
    camera_anchor_ = h3dAddGroupNode(H3DRootNode, "__cam_anchor__") ;

    emit sceneLoaded();

    if (0 == cur_camera_) {
        SetCurrentCamera(0) ;
    }
    
    timer_id_ = startTimer(0);

}

void GLPlayerWidget::resizeGL(int width, int height)
{	
    if ( initialized_) {
        // Resize viewport
        h3dSetNodeParamI( cur_camera_, H3DCamera::ViewportXI, 0 );
        h3dSetNodeParamI( cur_camera_, H3DCamera::ViewportYI, 0 );
        h3dSetNodeParamI( cur_camera_, H3DCamera::ViewportWidthI, width );
        h3dSetNodeParamI( cur_camera_, H3DCamera::ViewportHeightI, height );

        // Set virtual camera parameters
        h3dSetupCameraView( cur_camera_, 45.0f, (float)width / height, 0.1f, 1000.0f );
        H3DRes pipeline = h3dGetNodeParamI( cur_camera_, H3DCamera::PipeResI ) ;
        h3dResizePipelineBuffers( pipeline, width, height );
        
        camera_ctrl_->handleResize(width, height) ;
    }
}

void GLPlayerWidget::timerEvent( QTimerEvent *ev )
{
    if (ev->timerId() != timer_id_ ) return;
    updateGL();
}

void GLPlayerWidget::keyPressEvent( QKeyEvent *ev )
{
    QSimpleInputContext::instance()->SetKeyState(Qt::Key(ev->key()), true);
    
    if( ev->key() == Qt::Key_Space )
        m_freeze = !m_freeze;
    else if( ev->key() == Qt::Key_Escape ) {
        if( m_fullScreen )  {
            showNormal();
            m_fullScreen = false;
        } else close();
        
    } else if( ev->key() == Qt::Key_F1 && !m_fullScreen ) {
        m_fullScreen = true;
        showFullScreen();
    }
    else if( ev->key() == Qt::Key_F7 )
        m_debugViewMode = !m_debugViewMode;
    else if( ev->key() == Qt::Key_F8 )  // F8
        m_wireframeMode = !m_wireframeMode;
    else if( ev->key() == Qt::Key_F5 ) { // F5
        m_statMode += 1;
        if( m_statMode > H3DUTMaxStatMode ) m_statMode = 0;
    } else if( ev->key() == Qt::Key_1 ) {
        // Change blend weight
        m_weight += 2 / m_curFPS;
        if( m_weight > 1 ) m_weight = 1;
    } else if( ev->key() == Qt::Key_2 ) {
        // Change blend weight
        m_weight -= 2 / m_curFPS;
        if( m_weight < 0 ) m_weight = 0;
    } else {
        ev->ignore();
        return;
    }
    
    ev->accept();
}

void GLPlayerWidget::keyReleaseEvent( QKeyEvent *ev )
{
    QSimpleInputContext::instance()->SetKeyState(Qt::Key(ev->key()), false);
}


void GLPlayerWidget::mouse_button(QMouseEvent *event, bool down) 
{
    int button = 0 ;
    switch (event->button()) {
    case Qt::LeftButton :
        button = Mouse::LEFT ;
        break;
    case Qt::RightButton:
        button = Mouse::RIGHT ;
        break ;
    case Qt::MidButton:
        button = Mouse::MIDDLE ;
        break;
    default:
        break ;
    }
    
    int modifier = 0 ;
    switch (QApplication::keyboardModifiers()) {
    case Qt::ShiftModifier :
        modifier = Mouse::SHIFT ;
        break;
    case Qt::ControlModifier :
        modifier = Mouse::CTRL ;
        break ;
    case Qt::AltModifier:
        modifier = Mouse::ALT ;
        break ;
    default:
        break;
    }
    
    camera_ctrl_->handleMouseFunc(button, !down ? Mouse::UP: Mouse::DOWN,
                                  event->x(), event->y(), modifier) ;
}

void GLPlayerWidget::mousePressEvent(QMouseEvent *event)
{
    mouse_button(event, true) ;
    QSimpleInputContext::instance()->SetMouseState(Qt::MouseButton(event->button()), true, event->x(), event->y());
}

void GLPlayerWidget::mouseReleaseEvent(QMouseEvent *event) 
{
    mouse_button(event, false) ;
    QSimpleInputContext::instance()->SetMouseState(Qt::MouseButton(event->button()), false, event->x(), event->y());
}

void GLPlayerWidget::mouseMoveEvent(QMouseEvent *event)
{
    camera_ctrl_->handleMoveFunc(event->x(), event->y()) ;
    QSimpleInputContext::instance()->SetMouseState(Qt::MouseButton(event->button()), QSimpleInputContext::instance()->button_pressed(), event->x(), event->y());
}

void GLPlayerWidget::focusInEvent(QFocusEvent * event)
{
    frame_skip_ = false;
    timer_id_ = startTimer(0);
}

void GLPlayerWidget::focusOutEvent(QFocusEvent * event)
{
    frame_skip_ = true;
    killTimer(timer_id_);
    timer_id_ = 0;
}

void GLPlayerWidget::paintGL()
{
    static QTime initTime(QTime::currentTime());
    static int fps = 0;
    static int timerid = timer_id_;
    
    if ( timerid != timer_id_ ) {
        fps = 0;
        initTime = QTime::currentTime();
    }
    
    timerid = timer_id_;
    
    ++fps;
    int mseconds = initTime.msecsTo( QTime::currentTime() );
    if( fps%5 == 0 && mseconds >= 2000) {
        // Calculate frame rate
        m_curFPS =  fps * 1000.0f / mseconds;;
        // Reset counter
        fps = 0;
        initTime = QTime::currentTime();
    }
    
    frame_id_++;
    
    if ( 0 == cur_camera_ ) return ;

    makeCurrent();
    
    if( !m_freeze ) {
        m_animTime += 1.0f / m_curFPS;
        emit graphic_update(m_curFPS, m_animTime * 24.0f, m_weight);
    }

    h3dSetOption( H3DOptions::DebugViewMode, m_debugViewMode ? 1.0f : 0.0f );
    h3dSetOption( H3DOptions::WireframeMode, m_wireframeMode ? 1.0f : 0.0f );
    // Show stats
    h3dutShowFrameStats( m_fontMatRes, m_panelMatRes, m_statMode );

    /*// Show logo
    const float ww = (float)h3dGetNodeParamI( cur_camera_, H3DCamera::ViewportWidthI ) /
                     (float)h3dGetNodeParamI( cur_camera_, H3DCamera::ViewportHeightI );
    const float ovLogo[] = {
        ww-0.4f, 0.8f, 0, 1,
        ww-0.4f, 1, 0, 0,
        ww, 1, 1, 0,
        ww, 0.8f, 1, 1 };
    h3dShowOverlays( ovLogo, 4, 1.f, 1.f, 1.f, 1.f, m_logoMatRes, 0 );*/

    // Render scene
    h3dRender( cur_camera_ );
    
    // Update physics
    if( !m_freeze ) {
        h3dextUpdatePhysics();
    } else {
        h3dextResetPhysics();
        h3dextUpdatePhysics();
    }

    // Finish rendering of frame
    h3dFinalizeFrame();

    // Remove all overlays
    h3dClearOverlays();

    // Write all messages to log file
    h3dutDumpMessages();
    
    QSimpleInputContext::instance()->ResetClicked();
}


bool GLPlayerWidget::load_res_frome_qrc()
{
    bool result = true;

    // Get the first resource that needs to be loaded
    int res = h3dQueryUnloadedResource( 0 );

    char *dataBuf = 0;
    int bufSize = 0;
    
    while( res != 0 ) {
        QString filename = ":/" + QString::fromAscii(h3dGetResName( res ))  ;
        QFile  inf(filename);
        
        // Open resource file
        if( inf.open(QIODevice::ReadOnly) ) {
            // Find size of resource file
            int fileSize = inf.size();
            
            if( bufSize < fileSize  ) {
                delete[] dataBuf;
                dataBuf = new char[fileSize];
                if( !dataBuf ) {
                    bufSize = 0;
                    continue;
                }
                bufSize = fileSize;
            }
            if( fileSize == 0 )	continue;
            // Copy resource file to memory
            inf.read( dataBuf, fileSize );
            inf.close();
            // Send resource data to engine
            result &= h3dLoadResource( res, dataBuf, fileSize );
        } else  {
            // Tell engine to use the dafault resource by using NULL as data pointer
            h3dLoadResource( res, 0x0, 0 );
            result = false;
        }
        // Get next unloaded resource
        res = h3dQueryUnloadedResource( 0 );
    }
    delete[] dataBuf;
    
    return result;
}

