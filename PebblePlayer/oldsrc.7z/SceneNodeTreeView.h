
#pragma once

#include <QtGui/QTreeView>
#include <QStandardItemModel>
#include <QStandardItem>

/*class TestItem : public QStandardItem
{
    //Q_OBJECT
public :
    TestItem(QString name) : QStandardItem(name){}
    virtual ~TestItem()
    {
        printf("remove\n");
    }
};*/

class SceneStandardModel : public QStandardItemModel
{
    Q_OBJECT

public:
    SceneStandardModel(QObject *parent = 0) : QStandardItemModel(parent) {}
    virtual ~SceneStandardModel() {
        this->clearItems();
    }

public slots:
    void clearItems();
    int createItem(QString name, int node_id);
    QStandardItem *getItem(int idx);

private:
    typedef QList<QStandardItem*> ItemList;
    ItemList items_;
};


class SceneNodeTreeView : public QTreeView
{
    Q_OBJECT
public:
    SceneNodeTreeView(QWidget *parent = 0);

signals:

public slots:
    SceneStandardModel* defaultModel() {return defualt_model_;}

private:
    SceneStandardModel* defualt_model_;
};

