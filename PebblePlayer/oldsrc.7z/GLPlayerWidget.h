#ifndef GLPlayerWidget_H
#define GLPlayerWidget_H

#include <QGLWidget>
#include <Horde3D/Horde3D.h>

class TrackballManipulator;

class QSimpleInputContext : public QObject
{
    Q_OBJECT

public:
    void SetMouseState(Qt::MouseButton button, bool pressed, int x, int y) ;
    void SetKeyState(Qt::Key key, bool pressed);
    static QSimpleInputContext *instance() ;
    
    void ResetClicked() {key_clicked_ = button_clicked_ = false;}
    
public slots:
    Qt::Key key() const { return Qt::Key(key_); }
    bool key_pressed() const { return key_pressed_; }
    Qt::Key clicked_key() const { return Qt::Key(clicked_key_); }
    bool key_clicked() const { return key_clicked_; }
    
    Qt::MouseButton button() const { return Qt::MouseButton(button_); }
    bool button_pressed() const { return button_pressed_; }
    Qt::MouseButton clicked_button() const { return Qt::MouseButton(button_clicked_); }
    bool button_clicked() const { return button_clicked_; }
    
    int x() const {return x_;}
    int y() const {return y_;}
    
    Qt::KeyboardModifiers modifier() const ;
    
private:
    QSimpleInputContext() ;
    
private:
    int key_ ;
    int clicked_key_ ;
    int button_;
    int clicked_button_ ;
    int x_, y_;

    bool key_clicked_;
    bool key_pressed_;
    bool button_clicked_;
    bool button_pressed_;
    
    static QSimpleInputContext instance_;
};

class SPHExp : public QObject
{
    Q_OBJECT
public:
    SPHExp() : buf_(0x0), len_(0){}
    ~SPHExp() { if(buf_ && len_) delete[] buf_; }
    
public slots:
    int LoadVolumeData(const char* filename, int smooth_level=50) ;
    bool UpdateSphData(int sphres, const char* filename);
    void AdvanceSph(int sphnode);

private :
    char *buf_;
    size_t len_;
};

class GLPlayerWidget : public QGLWidget
{
    Q_OBJECT

public:
    GLPlayerWidget(QWidget *parent = 0);
    ~GLPlayerWidget();
    //Q_PROPERTY(QString test1 READ get_test1 WRITE set_test1 DESIGNABLE true USER true)
    
signals:
    void graphic_update(float curr_fps, float anim_time, float widget);
    void set_engine_options();
    void load_resource();
    void setup_scene();
    void sceneLoaded();
    
public slots:
    
    void SetCurrentCamera(int camera);
    int  GetCurrentCamera() const {return cur_camera_;}
    void Reset() ;

protected:
    void timerEvent( QTimerEvent *ev );
    void keyPressEvent( QKeyEvent *ev );
    void keyReleaseEvent( QKeyEvent *ev );
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void focusInEvent(QFocusEvent * event);
    void focusOutEvent(QFocusEvent * event);
    
    void initializeGL();
    void resizeGL(int width, int height);
    void paintGL();
    void mouse_button(QMouseEvent *event, bool down) ;

    bool load_res_frome_qrc();
    //QString get_test1() {return test1_;}
    //void set_test1(const QString& val) {test1_ = val;}

private:
    //QString test1_;
    bool initialized_;

    float m_curFPS;
    int   m_statMode;
    bool  m_freeze, m_debugViewMode, m_wireframeMode;
    float m_animTime;
    float m_weight;
    unsigned long frame_id_;
    bool  frame_skip_;
    int   timer_id_;

    bool  m_fullScreen;
    
    TrackballManipulator  *camera_ctrl_;
    
    H3DRes cur_camera_;
    H3DRes camera_anchor_;

    // Engine objects
    H3DRes m_fontMatRes, m_panelMatRes;
    H3DRes m_logoMatRes;

};

class GLPlayerWidgetWarpper : public QObject
{
    Q_OBJECT
public slots:
    GLPlayerWidget *new_GLPlayerWidget(QWidget *parent = 0) { return new GLPlayerWidget(parent); }
    void delete_GLPlayerWidget(GLPlayerWidget *widget) { widget->setParent(NULL); delete widget; }
} ;

#endif // GLPlayerWidget_H
