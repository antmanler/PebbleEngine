
#include <CustomTypes.h>
#include <EditorCore/Object3D.h>
#include "NodePropertyWidget.h"

NodePropertyWidget::NodePropertyWidget(QWidget *parent) :
    QPropertyEditorWidget(parent)
{
    CustomTypes::registerTypes();
    registerCustomPropertyCB(CustomTypes::createCustomProperty);
}

void NodePropertyWidget::addH3DObject(int h3d_id)
{
    if ( 0 == h3d_id ) return;
    Object3D *obj = new Object3D(this, h3d_id);
    setObject(obj);
}
