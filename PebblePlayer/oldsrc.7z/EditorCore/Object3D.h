#ifndef OBJECT3D_H
#define OBJECT3D_H

#include <QObject>
#include "CustomTypes.h"

class Object3D : public QObject
{
    Q_OBJECT
    Q_CLASSINFO("Object3D", "Transform")

    Q_PROPERTY(int ID READ hordeId DESIGNABLE true USER true)
    Q_PROPERTY(QString Name READ name WRITE setName DESIGNABLE true USER true)
    Q_PROPERTY(bool Active READ enabled WRITE setEnabled DESIGNABLE true USER true)
    Q_PROPERTY(QVec3f Translation READ translation WRITE setTranslation DESIGNABLE true USER true)
    Q_CLASSINFO("Translation", "decimalsX=4;decimalsY=4;decimalsZ=4;")
    Q_PROPERTY(QVec3f Rotation READ rotation WRITE setRotation DESIGNABLE true USER true)
    Q_CLASSINFO("Rotation", "decimalsX=4;decimalsY=4;decimalsZ=4;")
    Q_PROPERTY(QVec3f Scale READ scale WRITE setScale DESIGNABLE true USER true)
    Q_CLASSINFO("Scale", "minimumX=0;minimumY=0;minimumZ=0;decimalsX=4;decimalsY=4;decimalsZ=4;")

    //Q_PROPERTY(QMatrix4f __AbsoluteTransformation READ absTrans)
    //Q_PROPERTY(QMatrix4f __RelativeTransformation READ relTrans WRITE setRelTrans)
public:
    explicit Object3D(QObject *parent = 0, int horde_id = 0);

    /// The internal scene graph id in Horde3d
    unsigned int hordeId() const {return horde_id_;}

    /**
     * Node name attribute value
     * @return name attribute of the current node
     */
    QString name() const;
    void setName(const QString& name);

    QVec3f translation() const;
    void setTranslation(const QVec3f& translation);

    QVec3f rotation() const;
    void setRotation(const QVec3f& rotation);

    QVec3f scale() const;
    void setScale(const QVec3f& scale);

    bool enabled() const;
    void setEnabled(bool enabled);

signals:

public slots:

private:
    int horde_id_;

};

#endif // OBJECT3D_H
