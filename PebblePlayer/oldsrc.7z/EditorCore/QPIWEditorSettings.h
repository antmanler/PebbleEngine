

#ifndef QHORDESCENEEDITORSETTINGS_H_
#define QHORDESCENEEDITORSETTINGS_H_

#include <QtCore/QSettings>

/**
 * x
 */
class QPIWEditorSettings : public QSettings
{
public:
    QPIWEditorSettings(QObject * parent = 0);
};

#endif
