
#include <Horde3D/Horde3D.h>
#include "Object3D.h"

Object3D::Object3D(QObject *parent, int horde_id) :
    QObject(parent), horde_id_(horde_id)
{
}

QString Object3D::name() const
{
    if ( 0 == hordeId() ) return "Root";
    const char *name = h3dGetNodeParamStr(horde_id_, H3DNodeParams::NameStr);
    return name;
}

void Object3D::setName(const QString& name)
{
    if ( 0 == hordeId() ) return;
    h3dSetNodeParamStr(horde_id_, H3DNodeParams::NameStr, qPrintable(name));
}

QVec3f Object3D::translation() const
{
    if ( 0 == hordeId() ) return QVec3f();
    float x=0.0f, y=0.0f, z=0.0f;
    h3dGetNodeTransform(horde_id_, &x, &y, &z, NULL, NULL, NULL, NULL, NULL, NULL);
    return QVec3f(x, y, z);
}

void Object3D::setTranslation(const QVec3f& trans)
{
    QVec3f rotating = rotation();
    QVec3f scaling = scale();
    h3dSetNodeTransform(horde_id_, trans.X, trans.Y, trans.Z, rotating.X, rotating.Y, rotating.Z, scaling.X, scaling.Y, scaling.Z);
}

QVec3f Object3D::rotation() const
{
    if ( 0 == hordeId() ) return QVec3f();
    float x=0, y=0, z=0;
    h3dGetNodeTransform(horde_id_, NULL, NULL, NULL, &x, &y, &z, NULL, NULL, NULL);
    return QVec3f(x, y, z);
}

void Object3D::setRotation(const QVec3f& rotation)
{
    QVec3f pos = translation();
    QVec3f scaling = scale();
    h3dSetNodeTransform(horde_id_, pos.X, pos.Y, pos.Z, rotation.X, rotation.Y, rotation.Z, scaling.X, scaling.Y, scaling.Z);
}

QVec3f Object3D::scale() const
{
    if ( 0 == hordeId() ) return QVec3f();
    float x=0, y=0, z=0;
    h3dGetNodeTransform(horde_id_, NULL, NULL, NULL, NULL, NULL, NULL, &x, &y, &z);
    return QVec3f(x, y, z);
}

void Object3D::setScale(const QVec3f& scale)
{

    QVec3f pos = translation();
    QVec3f rot = rotation();
    h3dSetNodeTransform(horde_id_, pos.X, pos.Y, pos.Z, rot.X, rot.Y, rot.Z, scale.X, scale.Y, scale.Z);


}

bool Object3D::enabled() const
{
    return (h3dGetNodeFlags(horde_id_) & H3DNodeFlags::Inactive) == 0;
}

void Object3D::setEnabled(bool enabled)
{
    h3dSetNodeFlags(horde_id_, enabled ? 0 : H3DNodeFlags::Inactive, true);
}
