

#include "QPIWEditorSettings.h"
#include <QtCore/QDir>
#include <QtGui/QApplication>

QPIWEditorSettings::QPIWEditorSettings(QObject * parent) :
    #ifdef __APPLE__
    QSettings("antmanler.com", "PIWEditor", parent)
  #else
    QSettings(QApplication::applicationDirPath()+QDir::separator()+"PIWEditor.ini", QSettings::IniFormat, parent)
  #endif
{
}
