
#include "SceneNodeTreeView.h"


void SceneStandardModel::clearItems()
{
    clear();
//    while ( ! items_.empty() ) {
//        QStandardItem *item = items_.takeLast();
//        if(item) delete item;
//    }
//    ItemList::Iterator itr = items_.begin();
//    for (; itr != items_.end(); ++itr) delete (*itr);
    items_.clear();
}

QStandardItem *SceneStandardModel::getItem(int idx)
{
    if (idx >=0 && idx < items_.size() )
        return items_.at(idx);
    return NULL;
}

int SceneStandardModel::createItem(QString name, int node_id)
{
    QStandardItem* item = new QStandardItem(name); // new TestItem(name);
    item->setData(node_id);
    items_.push_back(item);
    return items_.size() - 1;
}

SceneNodeTreeView::SceneNodeTreeView(QWidget *parent)
    : QTreeView(parent)
{
    defualt_model_ = new SceneStandardModel(this);
}

