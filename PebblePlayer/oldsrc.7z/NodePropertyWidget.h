
#pragma once

#include <QPropertyEditor/QPropertyEditorWidget.h>

class NodePropertyWidget : public QPropertyEditorWidget
{
    Q_OBJECT
public:
    explicit NodePropertyWidget(QWidget *parent = 0);

signals:

public slots:
    void addH3DObject(int h3d_id);

};

