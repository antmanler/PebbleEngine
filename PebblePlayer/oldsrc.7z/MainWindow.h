#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "ui_mainwindow.h"

class PythonQtScriptingConsole;
class MainWindow : public QMainWindow, private Ui::PebbleEditor
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    void setupScriptingContext();

public slots:


private:
    //PythonQtScriptingConsole *script_console_;
};

#endif // MAINWINDOW_H
