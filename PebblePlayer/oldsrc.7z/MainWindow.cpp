#include <PythonQt/PythonQt.h>
#include <PythonQt/PythonQtScriptingConsole.h>
#include "MainWindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent)
{
    setupUi(this);
    // add console to main window
    /*QVBoxLayout *layout = new QVBoxLayout(frmConsole);
    layout->setObjectName(QString::fromUtf8("consoleLayout"));
    //layout->setContentsMargins(0, 0, 0, 0);
    script_console_ = new PythonQtScriptingConsole(frmConsole, PythonQt::self()->getMainModule());
    script_console_->setStyleSheet(QString::fromUtf8("QFrame{border-width:0 px;}"));
    layout->addWidget(script_console_);*/

}

void MainWindow::setupScriptingContext()
{
    PythonQtObjectPtr  __main__context = PythonQt::self()->getMainModule();
    PythonQtObjectPtr MainWindow = PythonQt::self()->createModuleFromScript("PiwMainWindow", "");
    MainWindow.addObject("script_console", txtConsole);
    MainWindow.addObject("horde_window", renderWidget);
    MainWindow.addObject("node_property_widget", tvNodeProperty);
    MainWindow.addObject("scene_tree_widget", tvScene);
    MainWindow.addObject("scene_tree_widget_default_model", tvScene->defaultModel());

    // add render widget to main context
    __main__context.addObject("script_console", txtConsole);
    __main__context.addObject("horde_window", renderWidget);
    __main__context.addObject("node_property_widget", tvNodeProperty);
    __main__context.addObject("scene_tree_widget", tvScene);
    txtConsole->appendCommandPrompt();
}
