
#pragma once

class Mouse 
{
public:
    enum MODIFIER {
        SHIFT = 0x100, CTRL, ALT
    } ;
    
    enum BUTTON {
        LEFT = 0x200, MIDDLE, RIGHT
    };
    
    enum STATE {
        DOWN = 0x300, UP, MOTION
    };
};

class TrackballManipulator {
public:
    TrackballManipulator();
    void setCamera(int camera);
    void handleMouseFunc(int button, int state, int x, int y, int modifier);
    void handleMoveFunc(int x, int y);
    void handleResize(int new_xres, int new_yres);
    

    
private:
    struct InteractionState {
        InteractionState():modifier(0), button(0), state(0) {}
        InteractionState(int modifier, int button, int state)
        : modifier(modifier), button(button), state(state)
        {}
        int modifier; // Shift,Ctrl,Alt
        int button;   // Left,Middle,Right
        int state;    // Down,Up
        int last_x, last_y;
    };
    
    void call_func(int x, int y);
    
    void translate(int x, int y);
    void rotate(int x, int y);
    void zoom(int x, int y);
    
    // utils
    vec3 compute_vector(int x, int y);
    inline mat4 get_camera_local_mat();
    void set_camera_local_mat(const mat4 &mat);
    
    // Data
    int camera_;
    InteractionState inter_state_;
    vec4 viewport_;
    mat4 start_mat_;
    vec3 pivot_;
    vec3 start_cam_pos_;
    vec3 start_pivot_;
    float rotate_speed_;
    float zoom_speed_;
    float translate_speed_;
};